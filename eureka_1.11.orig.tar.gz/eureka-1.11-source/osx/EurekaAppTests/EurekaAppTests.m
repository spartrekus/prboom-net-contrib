//
//  EurekaAppTests.m
//  EurekaAppTests
//
//  Created by Ioan on 20.11.2012.
//  Copyright (c) 2012 Ioan Chera
//

#import "EurekaAppTests.h"

@implementation EurekaAppTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in EurekaAppTests");
}

@end
