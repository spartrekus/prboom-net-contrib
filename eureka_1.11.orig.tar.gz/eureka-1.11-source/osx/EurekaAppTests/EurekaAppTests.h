//
//  EurekaAppTests.h
//  EurekaAppTests
//
//  Created by Ioan on 20.11.2012.
//  Copyright (c) 2012 Ioan Chera
//

#import <SenTestingKit/SenTestingKit.h>

@interface EurekaAppTests : SenTestCase

@end
